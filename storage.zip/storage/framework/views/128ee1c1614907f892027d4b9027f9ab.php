<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <style>
        #profileImage {
            width: 389px; 
            height: 653px; 
            left: 28px; 
            top: 186px; 
            position: absolute; 
            border-radius: 500px;
        }
        .hidden-file-input {
            display: none;
        }

        .back-button {
            width: 150px; 
            height: 45px; 
            left: 0px; 
            top: 4px; 
            position: absolute; 
            background: white; 
            border-radius: 5px; 
            border: 2px #FF7008 solid;
            cursor: pointer;
        }
        .back-button-text {
            left: 44px; 
            top: 4px; 
            position: absolute; 
            color: #FF7008; 
            font-size: 28px; 
            font-family: Roboto; 
            font-weight: 400; 
            word-wrap: break-word;
        }
    </style>
</head>
<body>
    <div style="width: 1170.47px; height: 400px; position: relative; background: white">
        <div style="width: 317px; height: 117px; left: 113px; top: 190px; position: absolute">
            <div style="width: 178px; height: 4px; left: 0px; top: -130px; position: absolute; color: #1C1C1C; font-size: 55px; font-family: Roboto; font-weight: 700; word-wrap: break-word">Profile</div>
            <div style="width: 1117px; height: 0px; left: 317px; top: -170px; position: absolute; transform: rotate(90deg); transform-origin: 0 0; border: 1px #858585 solid"></div>
        </div>

        <img id="profileImage" src="<?php echo e($user->image ? asset('storage/' . $user->image) : 'https://via.placeholder.com/389x653'); ?>" alt="Profile Image" />

        <div style="width: 876px; height: 108px; left: 460px; top: 200px; position: absolute">
            <div style="width: 876px; height: 70px; left: 0px; top: 38px; position: absolute; background: white; border-radius: 5px; border: 2px #858585 solid"></div>
            <div style="width: 276.86px; left: 0px; top: 0px; position: absolute; color: #1C1C1C; font-size: 26px; font-family: Roboto; font-weight: 600; word-wrap: break-word">Full Name</div>
            <div style="width: 500px; left: 27px; top: 59px; position: absolute; color: #858585; font-size: 24px; font-family: Roboto; font-weight: 500; word-wrap: break-word" ><?php echo e($user->fullname); ?></div>
        </div>

  <div style="width: 876px; height: 108px; left: 460px; top: 348px; position: absolute">
    <div style="width: 876px; height: 70px; left: 0px; top: 38px; position: absolute; background: white; border-radius: 5px; border: 2px #858585 solid"></div>
    <div style="width: 276.86px; left: 0px; top: 0px; position: absolute; color: #1C1C1C; font-size: 26px; font-family: Roboto; font-weight: 600; word-wrap: break-word">Address</div>
    <div style="width: 1000px; left: 27.19px; top: 59px; position: absolute; color: #858585; font-size: 24px; font-family: Roboto; font-weight: 500; word-wrap: break-word"><?php echo e($user->address); ?></div>
  </div>

  <div style="width: 405px; height: 108px; left: 460px; top: 490px; position: absolute">
    <div style="width: 405px; height: 70px; left: 0px; top: 38px; position: absolute; background: white; border-radius: 5px; border: 2px #858585 solid"></div>
    <div style="width: 66px; left: 0px; top: 0px; position: absolute; color: #1C1C1C; font-size: 26px; font-family: Roboto; font-weight: 600; word-wrap: break-word">City</div>
    <div style="width: 500px; left: 27px; top: 59px; position: absolute; color: #858585; font-size: 24px; font-family: Roboto; font-weight: 500; word-wrap: break-word"><?php echo e($user->city); ?></div>
  </div>
  <div style="width: 405px; height: 108px; left: 940px; top: 490px; position: absolute">
    <div style="width: 405px; height: 70px; left: 0px; top: 38px; position: absolute; background: white; border-radius: 5px; border: 2px #858585 solid"></div>
    <div style="width: 300px; left: 0px; top: 0px; position: absolute; color: #1C1C1C; font-size: 26px; font-family: Roboto; font-weight: 600; word-wrap: break-word">Place and Date of Birth</div>
    <div style="width: 500px; left: 27px; top: 59px; position: absolute; color: #858585; font-size: 24px; font-family: Roboto; font-weight: 500; word-wrap: break-word"><?php echo e($user->birthdate); ?></div>
  </div>
  <div style="width: 405px; height: 108px; left: 460px; top: 644px; position: absolute">
    <div style="width: 405px; height: 70px; left: 0px; top: 38px; position: absolute; background: white; border-radius: 5px; border: 2px #858585 solid"></div>
    <div style="width: 300px; left: 0px; top: 0px; position: absolute; color: #1C1C1C; font-size: 26px; font-family: Roboto; font-weight: 600; word-wrap: break-word">Gender</div>
    <div style="width: 82px; left: 27px; top: 59px; position: absolute; color: #858585; font-size: 24px; font-family: Roboto; font-weight: 500; word-wrap: break-word"><?php echo e($user->gender); ?></div>
  </div>
  <div style="width: 405px; height: 108px; left: 940px; top: 644px; position: absolute">
    <div style="width: 405px; height: 70px; left: 0px; top: 38px; position: absolute; background: white; border-radius: 5px; border: 2px #858585 solid"></div>
    <div style="width: 300px; left: 0px; top: 0px; position: absolute; color: #1C1C1C; font-size: 26px; font-family: Roboto; font-weight: 600; word-wrap: break-word">Role</div>
    <div style="width: 82px; left: 27px; top: 59px; position: absolute; color: #858585; font-size: 24px; font-family: Roboto; font-weight: 500; word-wrap: break-word"><?php echo e($user->role); ?></div>
  </div>

  <div style="width: 876px; height: 56px; left: 471px; top: 802px; position: absolute">
  <a href="/editprofile">
    <div style="width: 876px; height: 56px; left: 0px; top: 0px; position: absolute; background: #FF7008; border-radius: 5px"></div>
    <div style="width: 164px; height: 28px; left: 356px; top: 9px; position: absolute; color: white; font-size: 30px; font-family: Roboto; font-weight: 600; word-wrap: break-word">Edit Profile</div>
    </a>
</div>
  <div style="width: 56px; height: 53px; left: 36px; top: 938px; position: absolute; border-radius: 9px; border: 2px black solid">
    <img style="width: 56px; height: 53px; left: 0px; top: 0px; position: absolute" src="<?php echo e(asset('storage/b.png')); ?>" />
    <div><?php echo e($user->Whatsapp); ?></div>
  </div>
  <div style="width: 50px; height: 42px; left: 39px; top: 880px; position: absolute; border-radius: 7px; border: 2px black solid">
    <img style="width: 50px; height: 42px; left: 0px; top: 0px; position: absolute" src="<?php echo e(asset('storage/a.png')); ?>" />
  </div>
  <div style="width: 53px; height: 46px; left: 39px; top: 1005px; position: absolute; border-radius: 8px; border: 2px black solid">
    <img style="width: 53px; height: 46px; left: 0px; top: 0px; position: absolute" src="<?php echo e(asset('storage/c.png')); ?>" />
  </div>
  <div style="width: 56px; height: 55px; left: 36px; top: 1068px; position: absolute; border-radius: 11px; border: 2px black solid">
    <img style="width: 56px; height: 55px; left: 0px; top: 0px; position: absolute" src="<?php echo e(asset('storage/d.png')); ?>">
  </div>
  <div style="width: 180px; height: 55px; left: 1320px; top: 40px; position: absolute">
  <button class="back-button" onclick="window.location.href='/landingpageafterlogin'">
  <div class="back-button-text">Back</div>
  </button>
</div>
<script>
        document.getElementById('profileImage').addEventListener('click', function() {
            document.getElementById('fileInput').click();
        });

        document.getElementById('fileInput').addEventListener('change', function(event) {
            const file = event.target.files[0];
            if (file) {
                const reader = new FileReader();
                reader.onload = function(e) {
                    document.getElementById('profileImage').src = e.target.result;
                };
                reader.readAsDataURL(file);
            }
        });
    </script>
</body>
</html><?php /**PATH C:\xamppReal\Application\KBT_WEB\resources\views/account/coba.blade.php ENDPATH**/ ?>