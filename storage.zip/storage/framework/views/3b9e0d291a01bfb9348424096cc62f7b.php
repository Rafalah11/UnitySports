<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Halaman Landing Page</title>
    <style>
        /* CSS untuk transisi gambar yang halus */
        #bolaBasket {
            transition: opacity 1s ease-in-out;
        }

        *, html{
        padding: 0;
        margin: 0;
        box-sizing: border-box
    }

        body {
            margin: 0; /* Menghapus margin default dari body */
            overflow: hidden; /* Mencegah scroll */
            background: #121212 no-repeat center center fixed; /* Atur background dan tetapkan ke tengah */
            background-size: cover; /* Sesuaikan background agar sesuai dengan ukuran halaman */
        }

        nav{
        background-color: #121212;  
        display: flex;
        justify-content: space-between;
        padding : 3rem 9rem;
    }

    nav div img{
        width: 100px;
        border:1px solid white;
        position: absolute;
        top:14px;
        left: 10px;
    }

    nav ul{
        display: flex;
        align-items: center; 
        list-style:none;
        gap: 5rem;
    }

    nav ul li a{
        text-decoration: none;
        font-family : "Segoe UI", Tahoma;
        color : white;
        font-weight: 600;
        padding: 5px 0;
        transition: all;
        transition-duration: 2000ms;
    }

    nav ul li a:hover {
        border-bottom: 1px solid black;
    }


            /* untuk hi (username) */
    .dropdown {
        position: relative;
        display: inline-block;
        
     }

        .username-container {
        background: #FE7C45;
        padding: 5px 25px;
        border-radius: 55px;
        color: black; 
        display: inline-block;
        position: relative;
        z-index: 10;
        }

        .dropdown-content {
            display: none;
            position: absolute;
            background-color: #000000;
            min-width: 120px;
            box-shadow: 0px 8px 16px 0px rgba(0,0,0,0.2);
        }

        .dropdown:hover .dropdown-content {
        display: block; 
        z-index: 1;
        }

        .dropdown-content a {
        color: white; 
        padding: 12px 5px;
        text-decoration: none;
        display: block;
        
        }

         .dropdown-content a:hover {
        background-color: #000000; 
        }

        /* untuk hi (username) sampai sini */
    

    </style>
</head>
<body>
    
  <div style="width: 1170.47px; height: 485px; left: 9px; top: 113px; position: absolute">
    <div style="width: 1170.47px; height: 485px; left: 0px; top: 0px; position: absolute">
      <div style="width: 545.33px; height: 321.84px; left: 72.90px; top: 30px; position: absolute; transform: rotate(13.09deg); transform-origin: 0 0; background: rgba(255, 255, 255, 0.13); box-shadow: 105px 105px 105px; filter: blur(90px)"></div>
      <div style="width: 302px; height: 164px; left: 830px; top: 106.75px; position: absolute; transform: rotate(-20.70deg); transform-origin: 0 0; background: rgba(255, 255, 255, 0.09); box-shadow: 105px 105px 105px; filter: blur(105px)"></div>
    </div>
    <div style="width: 636px; height: 311px; left: 748px; top: 104px; position: absolute; text-align: justify">
      <span style="color: white; font-size: 35px; font-family: Montserrat; font-weight: 600; word-wrap: break-word">
      Asosiasi Sipil Pelatih Fisik Bola Basket Argentina<br/>
      </span>
      <span style="color: white; font-size: 25px; font-family: Montserrat; font-weight: 600; word-wrap: break-word">
        <br/>
      </span>
      <span style="color: white; font-size: 18px; font-family: Montserrat; font-weight: 600; word-wrap: break-word">
        <br/>
      </span>
      <span style="color: white; font-size: 18px; font-family: Montserrat; font-weight: 500; word-wrap: break-word;">
      Kami berupaya untuk mendorong pengembangan profesional dan keunggulan dalam persiapan fisik para atlet kami. Kami bekerja untuk meningkatkan kinerja para pemain dan berkontribusi pada pertumbuhan olahraga nasional kami. Bergabunglah dengan kami dan bersama-sama mari kita bawa bola basket Argentina ke level yang lebih tinggi!
      </span>
    </div>
    <img id="bolaBasket" style="width: 420px; height: 377px; left: 121px; top: 22px; position: absolute" src="<?php echo e(asset('storage/bolabasket.png')); ?>" onclick="changeImage()" />
  </div>

  <!-- NAVBAR PALING ATAS -->
  <nav>
        <div class="">
                <img src="<?php echo e(asset('storage/LogoBIR.jpg')); ?>" alt="LOGO">
        </div>
        <ul>
            <li>
            <a href="<?php echo e(route('landingpageafterlogin')); ?>">Home</a>
            </li>
            <li>
            <a href="<?php echo e(route('lapangan')); ?>">Info Lapangan</a>  
            </li>
            <li>
            <a href="<?php echo e(route('agenda')); ?>">Agenda</a>
            </li>
            <li>
            <div class="dropdown" >
            <?php if(Auth::check()): ?>
            <div class="username-container"><?php echo e('Hi, ' . ($user->fullname)); ?></div>
            <div class="dropdown-content">
            <a href="<?php echo e(route('profile.show')); ?>">My Account</a>
            <a href="<?php echo e(route('logout')); ?>"
               onclick="event.preventDefault(); document.getElementById('logout-form').submit();">Log Out</a>
            <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" style="display: none;">
                <?php echo csrf_field(); ?>
            </form>
        </div>
    <?php else: ?>
        <button>
            <a href="<?php echo e(route('login')); ?>" style="color: inherit; text-decoration: none;">Login</a>
        </button>
    <?php endif; ?>
</div>  
          </li>
        </ul>
    </nav>
        <!-- NAVBAR PALING ATAS SAMPAI SINI -->

    </div>
  </div>
  
  <img style="width: 70px; height: 77px; left: 1327px; top: 478px; position: absolute" src="<?php echo e(asset('storage/whatsappicon.png')); ?>" />
</div>

<script>
  var currentImage = 0;
  var images = [
    '<?php echo e(asset('storage/bolabasket.png')); ?>',
    '<?php echo e(asset('storage/kock.png')); ?>',
    '<?php echo e(asset('storage/futsal.png')); ?>'
  ];

  function changeImage() {
    var img = document.getElementById('bolaBasket');
    currentImage = (currentImage + 1) % images.length;
    img.style.opacity = 0;
    setTimeout(function() {
      img.src = images[currentImage];
      img.style.opacity = 1;
    }, 500); // 500ms is the duration of the fade-out
  }

  // Change image every 6 seconds
  setInterval(changeImage, 6000);
</script>

</body>
</html>
<?php /**PATH C:\xamppReal\Application\KBT_WEB\resources\views/LP/landingpageadmin.blade.php ENDPATH**/ ?>