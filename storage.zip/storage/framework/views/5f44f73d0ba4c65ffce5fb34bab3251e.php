<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <meta http-equiv="X-UA-Compatible" content="ie=edge" />
    <title>Form</title>
    <style>
      /* Import Google font - Poppins */
      @import url("https://fonts.googleapis.com/css2?family=Poppins:wght@200;300;400;500;600;700&display=swap");
      * {
        margin: 0;
        padding: 0;
        box-sizing: border-box;
        font-family: "Poppins", sans-serif;
      }
      body {
        min-height: 100vh;
        display: flex;
        align-items: center;
        justify-content: center;
        padding: 20px;
        background: #FE7C45;
      }
      .container {
        position: relative;
        max-width: 700px;
        width: 100%;
        background:  #fff;
        padding: 25px;
        border-radius: 8px;
        box-shadow: 0 0 15px rgba(0, 0, 0, 0.1);
      }
      .container header {
        font-size: 1.5rem;
        color: #333;
        font-weight: 500;
        text-align: center;
      }
      .container .form {
        margin-top: 30px;
      }
      .form .input-box {
        width: 100%;
        margin-top: 20px;
      }
      .input-box label {
        color: #333;
      }
      .form :where(.input-box input, .select-box) {
        position: relative;
        height: 50px;
        width: 100%;
        outline: none;
        font-size: 1rem;
        color: #707070;
        margin-top: 8px;
        border: 1px solid #ddd;
        border-radius: 6px;
        padding: 0 15px;
      }
      .input-box input:focus {
        box-shadow: 0 1px 0 rgba(0, 0, 0, 0.1);
      }
      .form .column {
        display: flex;
        column-gap: 15px;
      }

      .form :where(.gender-option, .gender) {
        display: flex;
        align-items: center;
        column-gap: 50px;
        flex-wrap: wrap;
      }
      .address :where(input, .select-box) {
        margin-top: 15px;
      }
      .select-box select {
        height: 100%;
        width: 100%;
        outline: none;
        border: none;
        color: #707070;
        font-size: 1rem;
      }

      .select-box1 select {
        height: 100%;
        width: 100%;
        outline: none;
        border: none;
        color: #707070;
        font-size: 1rem;
      }
      .form button {
        height: 55px;
        width: 100%;
        color: #fff;
        font-size: 1rem;
        font-weight: 400;
        margin-top: 30px;
        border: none;
        cursor: pointer;
        transition: all 0.2s ease;
        background: #00000f;
      }
      .form button:hover {
        background: #FE7C45;
      }
      /*Responsive*/
      @media screen and (max-width: 500px) {
        .form .column {
          flex-wrap: wrap;
        }
        .form :where(.gender-option, .gender) {
          row-gap: 15px;
        }
      }

      /* AGAR TIDAK BISA NAMBAH 1 DAN KURANG 1 */
      input[type=number]::-webkit-outer-spin-button,
      input[type=number]::-webkit-inner-spin-button {
          -webkit-appearance: none;
          margin: 0;
      }

      input[type=number] {
          -moz-appearance: textfield;
      }
            /* AGAR TIDAK BISA NAMBAH 1 DAN KURANG 1 SAMPAI SINI */
    </style>

    <script>
    document.addEventListener('DOMContentLoaded', function() {
        const input = document.querySelector('input[name="kontak"]');
        // Membatasi panjang input
        input.addEventListener('input', function() {
            if (this.value.length > 15) {
                this.value = this.value.slice(0, 15);
            }
        });
        // Mencegah perubahan nilai dengan tombol panah
        input.addEventListener('keydown', function(e) {
            if (e.key === 'ArrowUp' || e.key === 'ArrowDown') {
                e.preventDefault();
            }
        });
    });
    </script>
  
  </head>
  <body>
    <section class="container">
      <header>Registration Form</header>
      <form action="/form" method="POST" enctype="multipart/form-data" class="form">
        <?php echo csrf_field(); ?>
        <div class="input-box">
          <label>Nama Komunitas</label>
          <input type="text" name="nama_komunitas" placeholder="Masukan nama komunitas anda" required />
        </div>

        <div class="input-box address">
          <label>Pilihan Olahraga</label>
          <div class="column">
            <div class="select-box">
                <select name="pilihan_olahraga">
                <option hidden>Olahraga apa yang ingin anda buat</option>
                <option value="BADMINTON">BADMINTON</option>
                <option value="FUTSAL">FUTSAL</option>
                <option value="BASKET">BASKET</option>
                <option value="SEPAK BOLA">SEPAK BOLA</option>
              </select>
            </div>
          </div>
          <input type="text" name="level" placeholder="Masukan Level" required />
          <input type="text" name="harga" placeholder="Masukan Harga" required />
        </div>

        <div class="column">
          <div class="input-box">
            <label>Phone Number</label>
            <input type="number" name="kontak" placeholder="Enter phone number" required />
          </div>
          <div class="input-box">
            <label>Date</label>
            <input type="date" name="date" placeholder="Enter birth date" required />
          </div>
        </div>
        <div class="input-box address">
          <label>Address</label>
          <input type="text" name="alamat" placeholder="Enter street address" required />
             <div class="column">
               <div class="select-box">
                 <select name="provinsi">
                   <option hidden>Provinsi</option>
                   <option>America</option>
                   <option>Japan</option>
                   <option>India</option>
                   <option>Nepal</option>
                 </select>
               </div>
             </div>
           </div>


           <div class="input-box address">
                <label>Masukan Gambar</label>
                <input type="file" name="image">
            </div>
           <button type="submit">Submit</button>
         </form>
       </section>
     </body>
   </html>
<?php /**PATH C:\xamppReal\Application\KBT_WEB\resources\views/AGD/formtambahagenda.blade.php ENDPATH**/ ?>