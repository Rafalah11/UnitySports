<?php
$host = 'localhost'; // Sesuaikan dengan host Anda
$dbname = 'kbt'; // Nama database Anda
$username = 'root'; // Username database
$password = ''; // Password database

try {
    // Membuat koneksi PDO
    $pdo = new PDO("mysql:host=$host;dbname=$dbname", $username, $password);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
} catch (PDOException $e) {
    echo 'Koneksi gagal: ' . $e->getMessage();
}
?>


<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Daftar Lapangan</title>
    <link href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css" rel="stylesheet">
    <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.5.4/dist/umd/popper.min.js"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
    <style>

    *, html{
        padding: 0;
        margin: 0;
        box-sizing: border-box
    }

    body{
            margin: 0;
            overflow-x: hidden;
            background: #121212 no-repeat center center fixed;
            background-size: cover;
            font-family: Montserrat, sans-serif;
            color: white;
    }
    
    nav{
        background-color: black;  
        display: flex;
        justify-content: space-between;
        padding : 1rem 2rem;
    }

    nav div img{
        width: 90px;
        border:1px solid white;
    }

    nav ul{
        display: flex;
        align-items: center; 
        list-style:none;
        gap: 5rem;
    }

    nav ul li a{
        text-decoration: none;
        font-family : "Segoe UI", Tahoma;
        color : white;
        font-weight: 600;
        padding: 5px 0;
        transition: all;
        transition-duration: 2000ms;
    }

    nav ul li a:hover {
        border-bottom: 1px solid black;
    }

    /* untuk hi (username) */
    .dropdown {
        position: relative;
        display: inline-block;
        
     }

        .username-container {
        background: #FE7C45;
        padding: 5px 25px;
        border-radius: 55px;
        color: black; 
        display: inline-block;
        position: relative;
        z-index: 10;
        }

        .dropdown-content {
            display: none;
            position: absolute;
            background-color: #000000;
            min-width: 120px;
            box-shadow: 0px 8px 16px 0px rgba(0,0,0,0.2);
        }

        .dropdown:hover .dropdown-content {
        display: block; 
        z-index: 1;
        }

        .dropdown-content a {
        color: white; 
        padding: 12px 5px;
        text-decoration: none;
        display: block;
        
        }

         .dropdown-content a:hover {
        background-color: #000000; 
        }

        /* untuk hi (username) sampai sini */

.tabel_lapangan {
    width: 100%;
    overflow-x: auto;
    margin-top:250px;
}

.responsive-table {
    width: 100%;
    border-collapse: collapse;
    
}

.responsive-table th, .responsive-table td {
    border: 1px solid #ddd;
    padding: 8px;
    text-align: left;
}

.responsive-table th {
    background-color: #FE7C45;
}


.btn-edit, .btn-delete, .btn-tambah {
    padding: 6px 12px;
    margin-right: 5px;
    cursor: pointer;
}

.btn-edit {
    background-color: #4CAF50;
    color: white;
    border: none;
    margin-right: 10px; 
}

.btn-delete {
    background-color: #f44336;
    color: white;
    border: none;
    margin-left: 5px; 
}


.btn-tambah {
    margin-top: 10px;
    padding: 8px 16px;
    background-color: #008CBA;
    color: white;
    border: none;
    cursor: pointer;
}

.btn-tambah:hover, .btn-edit:hover, .btn-delete:hover {
    opacity: 0.8;
}

@media screen and (max-width: 600px) {
    .responsive-table {
        overflow-x: auto;
        display: block;
        white-space: nowrap;
    }
    .responsive-table thead, .responsive-table tbody, .responsive-table th, .responsive-table td, .responsive-table tr {
        display: block;
    }
    .responsive-table td, .responsive-table th {
        height: 35px;
    }
    .responsive-table thead {
        float: left;
    }
    .responsive-table tbody {
        width: auto;
        position: relative;
        overflow-x: auto;
        -webkit-overflow-scrolling: touch;
        white-space: nowrap;
        float: left;
    }
    .responsive-table td, .responsive-table th {
        border-bottom: 1px solid #ddd;
    }
    .responsive-table td:nth-child(1), .responsive-table th:nth-child(1) {
        background-color: #f2f2f2;
    }
    .responsive-table tr {
        display: inline-block;
        vertical-align: top;
    }
    .btn-edit, .btn-delete, .btn-tambah {
        float: right;
    }
    .btn-tambah {
        width: 100%;
        padding: 8px 16px;
        margin-top: 10px;
        background-color: #008CBA;
        color: white;
        border: none;
        cursor: pointer;
    }
    .btn-tambah:hover, .btn-edit:hover, .btn-delete:hover {
        opacity: 0.8;
    }
}


.tabel-lapangan-2 {
    width: 100%;
    overflow-x: auto;
    margin-top:250px;
}

.responsive-table-custom-2 {
    width: 100%;
    border-collapse: collapse;
    
}

.responsive-table-custom-2 th, .responsive-table-custom-2 td {
    border: 1px solid #ddd;
    padding: 8px;
    text-align: left;
}

.responsive-table-custom-2 th {
    background-color: #FE7C45;
}


.btn-edit-custom-2, .btn-delete-custom-2, .btn-tambah {
    padding: 6px 12px;
    margin-right: 5px;
    cursor: pointer;
}

.btn-edit-custom-2 {
    background-color: #4CAF50;
    color: white;
    border: none;
    margin-right: 10px; 
}

.btn-delete-custom-2 {
    background-color: #f44336;
    color: white;
    border: none;
    margin-left: 5px; 
}


.btn-tambah {
    margin-top: 10px;
    padding: 8px 16px;
    background-color: #008CBA;
    color: white;
    border: none;
    cursor: pointer;
}

.btn-tambah:hover, .btn-edit-custom-2:hover, .btn-delete-custom-2:hover {
    opacity: 0.8;
}

@media screen and (max-width: 600px) {
    .responsive-table-custom-2 {
        overflow-x: auto;
        display: block;
        white-space: nowrap;
    }
    .responsive-table-custom-2 thead, .responsive-table-custom-2 tbody, .responsive-table-custom-2 th, .responsive-table-custom-2 td, .responsive-table-custom-2 tr {
        display: block;
    }
    .responsive-table-custom-2 td, .responsive-table-custom-2 th {
        height: 35px;
    }
    .responsive-table-custom-2 thead {
        float: left;
    }
    .responsive-table-custom-2 tbody {
        width: auto;
        position: relative;
        overflow-x: auto;
        -webkit-overflow-scrolling: touch;
        white-space: nowrap;
        float: left;
    }
    .responsive-table-custom-2 td, .responsive-table-custom-2 th {
        border-bottom: 1px solid #ddd;
    }
    .responsive-table-custom-2 td:nth-child(1), .responsive-table-custom-2 th:nth-child(1) {
        background-color: #f2f2f2;
    }
    .responsive-table-custom-2 tr {
        display: inline-block;
        vertical-align: top;
    }
    .btn-edit-custom-2, .btn-delete-custom-2, .btn-tambah {
        float: right;
    }
}


        
    </style>

</head>

<body>
    <nav>
        <div class="">
                <img src="<?php echo e(asset('storage/LogoBIR.jpg')); ?>" alt="LOGO">
        </div>
        <ul>
            <li>
            <a href="<?php echo e(route('landingpageafterlogin')); ?>">Home</a>
            </li>
            <li>
            <a href="<?php echo e(route('lapanganadmin')); ?>">Daftar Lapangan</a>
            </li>
            <li>
            <a href="<?php echo e(route('komunitasadmin')); ?>">Daftar Kegiatan Komunitas</a>
            </li>
            <li>
            <div class="dropdown" >
            <?php if(Auth::check()): ?>
            <div class="username-container"><?php echo e('Hi, ' . ($user->fullname)); ?></div>
            <div class="dropdown-content">
            <a href="<?php echo e(route('profile.showadmin')); ?>">My Account</a>
            <a href="<?php echo e(route('logout')); ?>"
               onclick="event.preventDefault(); document.getElementById('logout-form').submit();">Log Out</a>
            <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" style="display: none;">
                <?php echo csrf_field(); ?>
            </form>
        </div>
    <?php else: ?>
        <button>
            <a href="<?php echo e(route('login')); ?>" style="color: inherit; text-decoration: none;">Login</a>
        </button>
    <?php endif; ?>
</div>
            </li>
        </ul>
    </nav>

</div>

<div class="tabel_lapangan">
    <table class="responsive-table">
        <thead>
            <tr>
                <th>NO</th>
                <th>Nama Lengkap</th>
                <th>Role</th>
                <th>Jenis Kelamin</th>
                <th>Kontak Whatsapp</th>
                <th>Aksi</th>
        </thead>
        <tbody>
            <!-- Contoh baris data, Anda dapat menambahkan data sesuai kebutuhan -->
            <?php
// Mengambil data dari database
$stmt = $pdo->query(
    "SELECT
    id, fullname, role, gender, WA
    FROM users
    WHERE role = 'VIP';"
);
$counter = 1;

// Loop untuk menampilkan data
while ($row = $stmt->fetch(PDO::FETCH_ASSOC)) {
    echo "<tr>";
    echo "<td>" . $counter++ . "</td>";
    echo "<td>" . $row['fullname'] . "</td>";
    echo "<td>" . $row['role'] . "</td>";
    echo "<td>" . $row['gender'] . "</td>";
    echo "<td>" . $row['WA'] . "</td>";
    echo "<td>";
    echo "<a href='" . route('formagenda', ['id' => $row['id']]) . "' class='btn btn-primary'>Edit</a>";
    echo "<form action='" . route('lapangan.destroy', ['id' => $row['id']]) . "' method='POST' style='display: inline;'>";
    echo csrf_field(); 
    echo method_field('DELETE'); 
    echo "<button type='submit' class='btn btn-delete'>Hapus</button>";
    echo "</form>";

    echo "</td>";
    echo "</tr>";
}
?>
               </tbody>
            </table>
        </div>


<div class="tabel-lapangan-2">
    <table class="responsive-table-custom-2">
        <thead>
            <tr>
                <th>NO</th>
                <th>Nama Lengkap</th>
                <th>Role</th>
                <th>Jenis Kelamin</th>
                <th>Kontak Whatsapp</th>
                <th>Aksi</th>
            </tr>
        </thead>
        <tbody>
            <!-- Loop untuk menampilkan data -->
            <?php

$stmt = $pdo->query(
    "SELECT
    id, fullname, role, gender, WA
    FROM users
    WHERE role = 'NVIP';"
);
$counter = 1;
            while ($row = $stmt->fetch(PDO::FETCH_ASSOC)) {
                echo "<tr>";
                echo "<td>" . $counter++ . "</td>";
                echo "<td>" . htmlspecialchars($row['fullname']) . "</td>";
                echo "<td>" . htmlspecialchars($row['role']) . "</td>";
                echo "<td>" . htmlspecialchars($row['gender']) . "</td>";
                echo "<td>" . htmlspecialchars($row['WA']) . "</td>";
                echo "<td>";
                echo "<a href='" . route('formagenda', ['id' => $row['id']]) . "' class='btn btn-primary'>Edit</a>";
                echo "<form action='" . route('lapangan.destroy', ['id' => $row['id']]) . "' method='POST' style='display: inline;'>";
                echo csrf_field();
                echo method_field('DELETE');
                echo "<button type='submit' class='btn-delete-custom-2'>Hapus</button>";
                echo "</form>";
                echo "</td>";
                echo "</tr>";
            }
            ?>
        </tbody>
    </table>
</div>
<?php echo $__env->make('sweetalert::alert', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
</body>
</html><?php /**PATH C:\xamppReal\Application\KBT_WEB\resources\views/CMTY/datavip.blade.php ENDPATH**/ ?>