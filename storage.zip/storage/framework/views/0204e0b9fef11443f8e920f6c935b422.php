<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Halaman Landing Page</title>
    <style>
        /* CSS untuk transisi gambar yang halus */
        #bolaBasket {
            transition: opacity 1s ease-in-out;
        }

        body {
            margin: 0; /* Menghapus margin default dari body */
            overflow: hidden; /* Mencegah scroll */
            background: #121212 no-repeat center center fixed; /* Atur background dan tetapkan ke tengah */
            background-size: cover; /* Sesuaikan background agar sesuai dengan ukuran halaman */
        }
    </style>
</head>
<body>
    
  <div style="width: 1170.47px; height: 485px; left: 9px; top: 113px; position: absolute">
    <div style="width: 1170.47px; height: 485px; left: 0px; top: 0px; position: absolute">
      <div style="width: 545.33px; height: 321.84px; left: 72.90px; top: 30px; position: absolute; transform: rotate(13.09deg); transform-origin: 0 0; background: rgba(255, 255, 255, 0.13); box-shadow: 105px 105px 105px; filter: blur(90px)"></div>
      <div style="width: 302px; height: 164px; left: 830px; top: 106.75px; position: absolute; transform: rotate(-20.70deg); transform-origin: 0 0; background: rgba(255, 255, 255, 0.09); box-shadow: 105px 105px 105px; filter: blur(105px)"></div>
    </div>
    <div style="width: 636px; height: 311px; left: 748px; top: 104px; position: absolute; text-align: justify">
      <span style="color: white; font-size: 35px; font-family: Montserrat; font-weight: 600; word-wrap: break-word">
      Asosiasi Sipil Pelatih Fisik Bola Basket Argentina<br/>
      </span>
      <span style="color: white; font-size: 25px; font-family: Montserrat; font-weight: 600; word-wrap: break-word">
        <br/>
      </span>
      <span style="color: white; font-size: 18px; font-family: Montserrat; font-weight: 600; word-wrap: break-word">
        <br/>
      </span>
      <span style="color: white; font-size: 18px; font-family: Montserrat; font-weight: 500; word-wrap: break-word;">
      Kami berupaya untuk mendorong pengembangan profesional dan keunggulan dalam persiapan fisik para atlet kami. Kami bekerja untuk meningkatkan kinerja para pemain dan berkontribusi pada pertumbuhan olahraga nasional kami. Bergabunglah dengan kami dan bersama-sama mari kita bawa bola basket Argentina ke level yang lebih tinggi!
      </span>
    </div>
    <img id="bolaBasket" style="width: 420px; height: 377px; left: 121px; top: 22px; position: absolute" src="<?php echo e(asset('storage/bolabasket.png')); ?>" onclick="changeImage()" />
  </div>
  <div style="width: 1096px; height: 45px; left: 361px; top: 33px; position: absolute">
    <div style="left: -231px; top: 4px; position: absolute; color: white; font-size: 30px; font-family: Montserrat; font-weight: 700; word-wrap: break-word">ACPFBA</div>
    <div style="left: 660px; top: 11px; position: absolute; color: white; font-size: 18px; font-family: Montserrat; font-weight: 600; word-wrap: break-word">Awal</div>
    <div style="left: 810px; top: 12px; position: absolute; color: white; font-size: 18px; font-family: Montserrat; font-weight: 600; word-wrap: break-word">Community</div>
    <div style="left: 727px; top: 12px; position: absolute; color: white; font-size: 18px; font-family: Montserrat; font-weight: 600; word-wrap: break-word">
    <a href="<?php echo e(route('agenda')); ?>" style="color: inherit; text-decoration: none;">Agenda</a>
</div>

    <div style="width: 99px; height: 31px; left: 934px; top: 7px; position: absolute">
      <div style="width: 99px; height: 31px; left: 0px; top: 0px; position: absolute; background: #FE7C45"></div>
      <div style="left: 23px; top: 5px; position: absolute; color: black; font-size: 18px; font-family: Montserrat; font-weight: 600; word-wrap: break-word">Login</div>
    </div>
  </div>
  
  <img style="width: 70px; height: 77px; left: 1327px; top: 478px; position: absolute" src="<?php echo e(asset('storage/whatsappicon.png')); ?>" />
</div>

<script>
  var currentImage = 0;
  var images = [
    '<?php echo e(asset('storage/bolabasket.png')); ?>',
    '<?php echo e(asset('storage/kock.png')); ?>',
    '<?php echo e(asset('storage/futsal.png')); ?>'
  ];

  function changeImage() {
    var img = document.getElementById('bolaBasket');
    currentImage = (currentImage + 1) % images.length;
    img.style.opacity = 0;
    setTimeout(function() {
      img.src = images[currentImage];
      img.style.opacity = 1;
    }, 500); // 500ms is the duration of the fade-out
  }

  // Change image every 6 seconds
  setInterval(changeImage, 6000);
</script>

</body>
</html>
<?php /**PATH C:\xamppReal\Application\KBT_WEB\resources\views/LP/landingpage.blade.php ENDPATH**/ ?>